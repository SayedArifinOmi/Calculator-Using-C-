# Calculator
Created a simple Calculator app using C# Windows Application Form
